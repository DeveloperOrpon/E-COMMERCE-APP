const currencySymbol = '৳';
