const String appName = "GreenMart";

class NotificationType {
  static String orderAccept = "Order Has Accept";
  static String orderReject = "Order Has Reject";
  static String ratingRemove = "Rating Has Remove";
  static String newProductAdded = "New Product Added";
}
